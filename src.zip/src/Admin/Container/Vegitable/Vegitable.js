import React from 'react';

function Vegitable(props) {
    return (
        <div>
            <h1>Vegitable page</h1>
        </div>
    );
}

export default Vegitable;